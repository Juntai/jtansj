package org.ansj.test;

import org.ansj.splitWord.analysis.NlpAnalysis;

public class NlpAnalysisTest {
	public static void main(String[] args) {
		System.out.println(NlpAnalysis.parse("东方不败笑傲江湖都是好看的电视剧"));
	}
}
